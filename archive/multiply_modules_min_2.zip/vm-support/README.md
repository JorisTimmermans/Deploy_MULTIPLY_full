# [![Build Status](https://travis-ci.org/multiply-org/vm-support.svg?branch=master)](https://travis-ci.org/multiply-org/vm-support)

# MULTIPLY Virtual Machine Support

This repository contains supporting functions to run and/or maintain the MULTIPLY platform in a Virtual Machine Environmnnt.
It is not thought of as part of the MULTIPLY platform per se and does not contain code that is essentially required for the platform.
