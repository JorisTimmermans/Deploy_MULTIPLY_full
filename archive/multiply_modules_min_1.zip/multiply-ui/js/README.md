A library of Jupyter Widgets for the MULTIPLY User Interface.

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save multiply-widgets
```
