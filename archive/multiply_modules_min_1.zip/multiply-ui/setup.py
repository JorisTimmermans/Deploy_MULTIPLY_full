from setuptools import setup, find_packages
version = None
with open('multiply_ui/version.py') as f:
    exec(f.read())

setup(
    name="multiply_ui",
    version=version,
    description='A GUI for the Multiply project based on Jupyter Notebook',
    license='MIT',
    author='Norman Fomferra',
    packages=find_packages(exclude=["test", "test.*"]),
    include_package_data=True,
    data_files=[('multiply_ui', ['multiply_ui/server/resources/processing-parameters.json',
                                 'multiply_ui/server/resources/pm_request_template.json',
                                 #'multiply_ui/server/resources/scripts/*.py',
                                 'multiply_ui/server/resources/scripts/__init__.py',
                                 'multiply_ui/server/resources/scripts/combine_biophys_outputs.py',
                                 'multiply_ui/server/resources/scripts/combine_hres_biophys_outputs.py',
                                 'multiply_ui/server/resources/scripts/create_s1_kaska_inference_output_files.py',
                                 'multiply_ui/server/resources/scripts/create_s2_kaska_inference_output_files.py',
                                 'multiply_ui/server/resources/scripts/data_access_get_static.py',
                                 'multiply_ui/server/resources/scripts/data_access_put_s2_l2.py',
                                 'multiply_ui/server/resources/scripts/determine_s1_priors.py',
                                 'multiply_ui/server/resources/scripts/get_data_for_s1_preprocessing.py',
                                 'multiply_ui/server/resources/scripts/get_data_for_s2_preprocessing.py',
                                 'multiply_ui/server/resources/scripts/infer_s1_kaska.py',
                                 'multiply_ui/server/resources/scripts/infer_s2_kafka.py',
                                 'multiply_ui/server/resources/scripts/infer_s2_kaska.py',
                                 'multiply_ui/server/resources/scripts/post_process.py',
                                 'multiply_ui/server/resources/scripts/preprocess_s1.py',
                                 'multiply_ui/server/resources/scripts/preprocess_s2.py',
                                 'multiply_ui/server/resources/scripts/retrieve_s2_priors.py',
                                 'multiply_ui/server/resources/scripts/stack_s1.py',
                                 #'multiply_ui/server/resources/templates/*.json',
                                 'multiply_ui/server/resources/templates/infer-s2-kafka-template.json',
                                 #'multiply_ui/server/resources/workflows/*.py',
                                 'multiply_ui/server/resources/workflows/__init__.py',
                                 'multiply_ui/server/resources/workflows/infer-s2-kafka-workflow.py',
                                 'multiply_ui/server/resources/workflows/multiply-full-workflow.py',
                                 'multiply_ui/server/resources/workflows/multiply_workflow.py',
                                 'multiply_ui/server/resources/workflows/only-get-data-workflow.py',
                                 'multiply_ui/server/resources/workflows/only-get-priors-workflow.py',
                                 'multiply_ui/server/resources/workflows/preprocess-sar-workflow.py',
                                 ])],
    entry_points={
        'console_scripts': [
            'mui-server = multiply_ui.server.cli:main',
        ]},
    # install_requires=[
    #     'click',
    #     'ipywidgets',
    #     'jupyterlab',
    #     'numpy',
    #     'tornado',
    #     'xarray'
    # ],
)
