#!/home/joris/software/miniconda3/envs/multiply-platform/bin/python

import glob
import logging
import os
import shutil
import sys
import yaml
from gdal import Warp

script_progress_logger = logging.getLogger('ScriptProgress')
script_progress_logger.setLevel(logging.INFO)
script_progress_formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
script_progress_logging_handler = logging.StreamHandler()
script_progress_logging_handler.setLevel(logging.INFO)
script_progress_logging_handler.setFormatter(script_progress_formatter)
script_progress_logger.addHandler(script_progress_logging_handler)

# setup parameters
with open(sys.argv[1]) as f:
    parameters = yaml.load(f)
compute_only_aoi = parameters['S2-PreProcessing']['compute_only_roi']
aoi = parameters['General']['roi']

# pathnames
s2_l1c_dir = sys.argv[4]
brdf_des_dir = sys.argv[5]
emu_dir = sys.argv[6]
cams_dir = sys.argv[7]
vrt_dem_dir = sys.argv[8]
provided_sdrs_dir = sys.argv[9]
output_root_dir = sys.argv[10]

vrt_dem_file = glob.glob(vrt_dem_dir + '/' + '*.vrt')[0]
processor_dir = '/home/joris/software/atmospheric_correction/SIAC'
if not os.path.exists(output_root_dir):
    os.makedirs(output_root_dir)

aoi_part = ""
if compute_only_aoi:
    aoi_part = " -a \'" + aoi + "\'"


#import pdb
#pdb.set_trace()
dirs_utm_tiles =  glob.glob(s2_l1c_dir + "/*")
for dir_utm_tile in dirs_utm_tiles:
    dirs = glob.glob(dir_utm_tile + "/*/*/*/*/*")

    for i, directory in enumerate(dirs):
        script_progress_logger.info(f'{int((i/len(dirs)) * 100)}-{int(((i+1)/len(dirs)) * 100)}')
        directory_parts = directory.split('/')
        product_date =  '-'.join(directory_parts[-3:])
        product_tile = '_'.join(directory_parts[-6:-3])
        product_name = product_tile + '-ac'

        print(f'Start pre-processing S2 L1 data from {product_date} {product_name}')
        command = "PYTHONPATH=$PYTHONPATH:" + processor_dir + "/util python " + processor_dir + "/SIAC_S2.py -f " \
              + directory + "/ -m " + brdf_des_dir + " -e " + emu_dir + " -c " + cams_dir + " -d " \
              + vrt_dem_file + " -o False" + aoi_part
        os.system(command)

        output_dir = output_root_dir + '/' + product_date + '/' + product_name
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        cmd2 = "cp $(find " + directory + '/ -type f) ' + output_dir + '/'
        os.system(cmd2)

        # if multiple utm zone's are used, they first need to be reprojected to the same coordinate system'.
        if len(dirs_utm_tiles)>1:
            files = glob.glob(output_dir + '/*.tif')
            for org_file in files:
                dst_file = output_dir + '/' +  org_file.split('/')[-1]
                Warp(org_file, org_file ,dstSRS='EPSG:4326')

        cmd3 = "cp $(find " + directory + '/ -name "metadata.xml") ' + output_dir + '/'
        os.system(cmd3)

        cmd3 = "cp `readlink " + directory + "/MTD_MSIL1C.xml` " + output_dir + "/MTD_MSIL1C.xml"
        os.system(cmd3)
        paths_to_mtd_tl = glob.glob(os.path.join(directory, 'GRANULE/*/MTD_TL.xml'))
        if len(paths_to_mtd_tl) > 0:
            cmd4 = "cp `readlink " + paths_to_mtd_tl[0] + "` " + output_dir + "/MTD_TL.xml"
            os.system(cmd4)
provided_sdr_files = os.listdir(provided_sdrs_dir)
for provided_sdr_file in provided_sdr_files:
    shutil.copytree(os.path.join(provided_sdrs_dir, provided_sdr_file), os.path.join(output_root_dir, provided_sdr_file))
script_progress_logger.info('100-100')
