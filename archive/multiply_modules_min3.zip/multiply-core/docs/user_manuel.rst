===========
User Manual
===========

In-depth explanation of how to use the MULTIPLY platform

- From Command Line
- From UI

For the use from python, refer to the API descriptions of the components.
