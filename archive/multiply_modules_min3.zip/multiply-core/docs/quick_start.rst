Quick Start
===========

What is the fastest way to use the MULTIPLY platform?
