================================
MULTIPLY - Coarse Resolution Pre-Processing
================================

A suggestion for a structure is

- introduction
- concepts / algorithm
- user manual
- architecture
- api reference
