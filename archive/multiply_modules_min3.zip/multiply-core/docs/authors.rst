.. _authors:

Developers
==========

Data access
------------
.. include:: data-access/AUTHORS.rst

Atmospheric correction
----------------------
.. include:: atmospheric_correction/AUTHORS.rst

GP Emulator
------------
.. include:: gp_emulator/AUTHORS.rst

SAR pre processing
-------------------
.. include:: sar-pre-processing/AUTHORS.rst

Prior engine
-------------
.. include:: prior-engine/AUTHORS.rst
