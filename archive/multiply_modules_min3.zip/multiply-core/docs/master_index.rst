Welcome to MULTIPLY documentation!
==================================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   introduction
   components
   workflow
   quick_start
   user_manuel
   support

.. toctree::
    :maxdepth: 1
    :caption: anything else

    License <license>
    Authors <authors>

