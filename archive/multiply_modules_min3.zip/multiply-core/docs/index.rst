Welcome to the documentation of the MULTIPLY platform!
======================================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   introduction
   components
   workflow
   quick_start
   user_manuel
   support

.. toctree::
    :maxdepth: 1
    :caption: anything else

    Authors <authors>
    Change log <changes>

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
