__author__ = "Tonio Fincke (Brockmann Consult GmbH)"

"""
This package shows a simple example of a command line interface.
"""