# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from SFTP servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.2"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# python3 compatibility
# changes in 1.2
# re-scan from cursor, do not assume that inputs come in sequence

import os
import datetime
import paramiko
from imonitor import IMonitor
from imonitor import IFile

class SftpMonitor(IMonitor):

    def __init__(self, request, srchost, srcuser, srcpassword=None, srcroot='.', srcpattern=None, srccursor=None, destroot=".", srcremove=False, destmapping=None, destflatten=False, timemapping=None, destreplace=True):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor, destroot, srcremove, destmapping, destflatten, timemapping, destreplace)
        # override cursor with parameter again, do not use last report entry as preceding entries may arrive later
        self._srccursor = srccursor
        self._ssh = paramiko.SSHClient()
        self._ssh.load_system_host_keys(os.environ['HOME']+'/.ssh/known_hosts')
        self._ssh.set_missing_host_key_policy(paramiko.client.AutoAddPolicy())
        if (self._srcpassword):
            self._ssh.connect(self._srchost, username=self._srcuser, password=self._srcpassword)
        else:
            self._ssh.connect(self._srchost, username=self._srcuser)
        self._ftp = self._ssh.open_sftp()

    def ls(self, ifile):
        print('looking for data in ' + ifile.path)
        opath = self._output_of(ifile.path)
        is_beyond_cursor = self._srccursor is None or not self._srccursor.startswith(opath)
        try:
            l = []
            l0 = self._ftp.listdir_attr(self._srcroot + ifile.path)
            l0.sort(key=lambda line: line.longname[line.longname.rfind(' ')+1:])
            for x in l0:
                self._maybe_insert(l, ifile.path, is_beyond_cursor, x)
            return l
        except Exception as e:
            if (self._srcpassword):
                self._ssh.connect(self._srchost, username=self._srcuser, password=self._srcpassword)
            else:
                self._ssh.connect(self._srchost, username=self._srcuser)
            self._ftp = self._ssh.open_sftp()
            l = []
            l0 = self._ftp.listdir_attr(self._srcroot + ifile.path)
            l0.sort(key=lambda line: line.longname[line.longname.rfind(' ')+1:])
            for x in l0:
                self._maybe_insert(l, ifile.path, is_beyond_cursor, x)
            return l

    def _maybe_insert(self, list, path, is_beyond_cursor, line):
        name = line.longname[line.longname.rfind(' ')+1:]
        size = line.st_size
        date = datetime.datetime.utcfromtimestamp(line.st_mtime)
        # check whether path is young to avoid retrieval of file being currently written
        now = datetime.datetime.utcnow()
        age = now - date
        threshold = datetime.timedelta(seconds=1800)
        isYoung = age < threshold
        #
        filetype = line.longname[0]  # first letter only
        pathname = path + name
        if filetype == 'd':
            opath = self._output_of(pathname + '/')
        else:
            opath = self._output_of(pathname)
        if not is_beyond_cursor and self._srccursor.startswith(opath):
            # remove all collected entries before cursor
            while len(list) > 0:
                print('skipping pre-cursor entry ' + list.pop().url)
                # TODO Does the different ordering of url and path have an impact?
            if opath == self._srccursor and self._srccompletion == 'c':
                print('skipping pre-cursor entry ' + pathname)
                return
        # TODO verify whether this is applicable to all scenarios (fine with satsta)
        if self._srccursor and opath < self._srccursor:
            print('skipping pre-cursor entry ' + pathname)
            return
        if filetype != 'd' and self._pattern and not self._pattern.match(name):
            return
        if filetype == 'd':
            ifile = IFile(pathname + '/')
        else:
            ifile = IFile(opath, pathname, int(size))
        if ifile in self._history:
            print('skipping history entry ' + ifile.path)
            return
        if filetype != 'd' and isYoung:
            print('skipping young entry {}: {}'.format(ifile.path, str(date)))
            return
        for i in range(len(list)):
            if ifile.path <= list[i].path:
                list.insert(i, ifile)
                return
        list.append(ifile)

    def transfer(self, ifile):
        self.prepare_transfer(ifile)
        try:
            self._ftp.get(self._srcroot + ifile.url, self._destroot + ifile.path)
        except:
            try:
                if (self._srcpassword):
                    self._ssh.connect(self._srchost, username=self._srcuser, password=self._srcpassword)
                else:
                    self._ssh.connect(self._srchost, username=self._srcuser)
                self._ftp = self._ssh.open_sftp()
                self._ftp.get(self._srcroot + ifile.url, self._destroot + ifile.path)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
        self.finish_transfer(ifile)
        if self._srcremove:
            try:
                self._ftp.put('/dev/null', self._srcroot + ifile.url + '.ingested')
#                self._ftp.remove(self._srcroot + ifile.url)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
