# -*- coding: utf-8 -*-

"""Workflow engine extension for event handling and dynamic rules"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.8"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# aggregation rules implemented
# changes in 1.2
# dynamic rule implemented
# changes in 1.3
# python3 compatibility using six
# changes in 1.4
# object inheritance added to allow super calls in derived classes
# changes in 1.5
# status file lists job ids of async steps for lossless resume
# changes in 1.6
# parameter retrycode added, forwarded to PMonitor for offline data ingestion
# changes in 1.7
# handling of resume for dynamic rules improved
# pattern rm.add_current_event(rm.memorize(n,e)) and rm.close_trigger(rm.recall(n)) for dynamic chains
# changes in 1.8
# polling thread added for combination of catalogue query loop and async request submission

import re
import os
from glob import glob
from datetime import datetime, timedelta
from six.moves import queue
from paramiko import SSHClient
from paramiko.client import AutoAddPolicy
from threading import Thread, Condition, Lock
from pmonitor import PMonitor

class RMonitor(PMonitor):
    """
    Handles events by rules, generates and executes tasks with their dependencies.
    Maintains
      all that PMonitor maintains
      a list of rules
      a set of triggers and timers
      a list of raised events
      a list of passed events
    Usage:
      from rmonitor import RMonitor
      rm = RMonitor(request='rtest',types=[('subsetting',2),('formatting',2),('archiving',1),('cataloguing',1)],simulation=True)
      # rm, condition, step, post_condition, parameters, expected_size, time_threshold, period=None, time_element=None, time_format=None
      rm.register_rule(RMonitor.AggregatorRule(rm, '/incoming/A(.............).L1A_LAC.bz2', "l3", '/l3/modisa-%Y%j.nc', ['%Y%j'], 288, 43200, '\\1', '%Y%j%H%M%S', 86400))
      rm.register_rule(RMonitor.AggregatorRule(rm, '/incoming/LC8.*', "subsetting", '/l3/modisa-%Y%j.nc', ['%Y%j'], 288, 43200, 86400, '\\1', '%Y%j%H%M%S'))
      rm.register_rule(RMonitor.PatternRule(rm, "/incoming/([a-zA-Z0-9_-]+)/(LC8.*gz)", "subsetting", "/subset/\\1/\\1-\\2", ["\\1"]))
      rm.register_rule(RMonitor.PatternRule(rm, "/subset/([a-zA-Z0-9_-]+)/(.*gz)", "formatting", "/subset-nc/\\1/\\1-\\2", ["\\1"]))
      rm.register_rule(RMonitor.PatternRule(rm, "/subset-nc/([a-zA-Z0-9_-]+)/(.*gz)", "archiving", "/archive/\\1/\\1-\\2", ["\\1"]))
      rm.register_rule(RMonitor.PatternRule(rm, "/subset-nc/([a-zA-Z0-9_-]+)/(.*gz)", "cataloguing", "/catalogue/\\1/\\1-\\2", ["\\1"]))
      rm.register_trigger(RMonitor.FileTailTrigger(rm, "/home/boe/projects/bc-processing/pmonitor/pmonitor/rtest.list"))
    """

    class Task(object):
        """"
        Abstract task implementation.
        """
        def run(self):
            pass

    class Worker(Thread):
        """
        Worker thread that waits for tasks and executes them in FIFO order.
        """
        def __init__(self, name='worker'):
            Thread.__init__(self, name=name)
            self.tasks = queue.Queue();
            self._active = True
            self.start()

        def add(self, task):
            self.tasks.put(task)

        def run(self):
            while self._active:
                task = self.tasks.get()
                try:
                    task.run()
                except Exception as ex:
                    print(ex)
                self.tasks.task_done()

        def stop(self):
            self._active = False
            self.add(RMonitor.Task())

    class Polling(Thread):
        """
        Async status polling if main thread is used for ingestion queries
        """
        def __init__(self, rm, stop_if_idle=False, name="polling"):
            Thread.__init__(self, name=name)
            self.stop_if_idle = stop_if_idle
            self.rm = rm
        def run(self):
            self.rm.wait_for_completion(stop_if_idle=self.stop_if_idle)
        def stop(self):
            pass  # TODO implement

    def async_wait_for_completion(self, stop_if_idle=False):
        self.polling = RMonitor.Polling(self, stop_if_idle=stop_if_idle)
        self.polling.start()

    class Timer(Thread):
        """
        Timer thread that executes timer tasks repeatedly or once at their scheduled times and periods.
        """
        def __init__(self, name='timer'):
            Thread.__init__(self, name=name)
            self.tasks = []
            self._to_be_removed = None
            self._condition = Condition()
            self._active = True
            self.start()
        def schedule(self, task):
            with self._condition:
                if len(self.tasks) == 0 or task.nexttime < self.tasks[0].nexttime:
                    self.tasks.insert(0, task)
                    self._condition.notify()
                else:
                    for i in range(len(self.tasks)):
                        if task.nexttime < self.tasks[i].nexttime:
                            self.tasks.insert(i, task)
                            task = None
                            break
                    if task is not None:
                        self.tasks.append(task)
                        if len(self.tasks) == 1:
                            self._condition.notify()
        def cancel(self, task):
            with self._condition:
                if not self.tasks.remove(task):
                    self._to_be_removed = task
        def stop(self):
            with self._condition:
                self._active = False
                self._condition.notify()
        def run(self):
            self._condition.acquire()
            while self._active:
                now = datetime.utcnow()
                if len(self.tasks) > 0:
                    #print "Timer: waiting for", self.tasks[0], (self.tasks[0].next-now).total_seconds()
                    self._condition.wait((self.tasks[0].nexttime-now).total_seconds())
                else:
                    #print "Timer: waiting infinitely"
                    self._condition.wait(timedelta(1).total_seconds())
                now = datetime.utcnow()
                #print "Timer: waking up at", now
                if self._active and len(self.tasks) > 0 and self.tasks[0].nexttime <= now:
                    task = self.tasks.pop(0)
                    self._condition.release()
                    #print "Timer: running task", task
                    try:
                        task.run()
                    except Exception as ex:
                        print(ex)
                    self._condition.acquire()
                    if task != self._to_be_removed and task.period:
                        task.nexttime += task.period
                        for i in range(len(self.tasks)):
                            if task.nexttime < self.tasks[i].nexttime:
                                self.tasks.insert(i, task)
                                task = None
                                break
                        if task is not None:
                            self.tasks.append(task)
                    self._to_be_removed = None

    class TimerTask(Task):
        """
        Base implementation of a timer task with next execution time, an optional period, and a run method, triggers regularly an event constructed from execution time and pattern.
        rm.register_timer_task(TimerTask('2017-01-01T00:00:00', period=86400, rm=rm, pattern='/update/s2/%Y-%m-%d'))
        """
        def __init__(self, nexttime, period=None, rm=None, pattern=None):
            self.rm = rm
            self.nexttime = nexttime
            self.period = period
            self.pattern = pattern
        def __str__(self):
            return "ti " + str(self.nexttime) + ' ' + str(self.period) + ' ' + str(self.pattern)
        def run(self):
            self.rm.trigger(self.nexttime.strftime(self.pattern))

    class PatternRule(object):
        """
        Rule that matches an event with a pattern and executes a step with a single input.
        """
        def __init__(self, rm, precondition, step, postcondition, parameters, time_element=None, time_format=None):
            self.rm = rm
            self.pattern = re.compile(precondition)
            self.step = step
            self.postcondition = postcondition
            self.parameters = parameters
            self.time_element = time_element
            self.time_format = time_format
        def __str__(self):
            return 'ru ' + self.step + ' ' + self.pattern.pattern
        def apply(self, event):
            match = self.pattern.match(event)
            if match is not None:
                if self.time_element and self.time_format:
                    event_time = datetime.strptime(match.expand(self.time_element), self.time_format)
                    postcondition = event_time.strftime(match.expand(self.postcondition))
                    parameters = [event_time.strftime(match.expand(p)) for p in self.parameters]
                else:
                    postcondition = match.expand(self.postcondition)
                    parameters = [match.expand(x) for x in self.parameters]
                #self.rm.add_current_event(event)
                self.rm.execute(self.step, [event], [postcondition], parameters)
                #self.rm.trigger(postcondition)

    class DynamicRule(object):
        """
        Rule that matches an event with a pattern and runs a function to generate a step
        """
        def __init__(self, rm, precondition, implementation):
            self.rm = rm
            self.pattern = re.compile(precondition)
            self.implementation = implementation
        def __str__(self):
            return 'dy ' + self.implementation.__name__ + ' ' + self.pattern.pattern
        def apply(self, event):
            match = self.pattern.match(event)
            if match is not None:
                print('applying ' + self.implementation.__name__ + ' to ' + event + ': ' + self.pattern.pattern)
                self.implementation(self.rm, event)

    class AggregatorTask(TimerTask):
        """
        Timer task that collects inputs for a time interval and that executes a step with all inputs collected for that interval when execution time is reached.
        """
        def __init__(self, rule, interval_start, execution_time):
            RMonitor.TimerTask.__init__(self, execution_time)
            self.rule = rule
            self.interval_start = interval_start
            self.conditions = []
            if rule.collating:
                self.postconditions = [interval_start.strftime(self.rule.postcondition)]
            else:
                self.postconditions = []
        def __str__(self):
            return 'ag ' + self.rule.step + ' ' + str(self.interval_start) + ' ' + str(self.nexttime) + ' ' + str(len(self.conditions)) + '/' + str(self.rule.expected_size)
        def add_event(self, event, match):
            self.conditions.append(event)
            if not self.rule.collating:
                self.postconditions.append(self.interval_start.strftime(match.expand(self.rule.postcondition)))
        def run(self):
            #print '... mutex2 1 acquiring'
            with self.rule.rm._mutex2:
                #print '... mutex2 1 acquired'
                if self.interval_start:
                    parameters = [self.interval_start.strftime(p) for p in self.rule.parameters]
                    self.rule.tasks.remove(self)
                    super(RMonitor, self.rule.rm).execute(self.rule.step, self.conditions, self.postconditions, parameters)
                    #for p in self.postconditions:
                    #    self.rule.rm.trigger(p)
            #print '... mutex2 1 released'

    class AggregatorRule(object):
        """
        Rule that matches events and collects them to execute a step with the collected inputs.
        Criteria to stop collecting are  the number of expected events and a time threshold.
        There are periodic rules that collect e.g. daily events and fire with some offset after day ends. These rules delay their execution if events arrive late, in order to collect more events.
        There are non-periodic rules that nevertheless collects events related to some date, e.g. those of one month, e.g. to place the outputs in a respective directory.
        There are non-periodic rules that are agnostic to the content of the event and simply fire when expected number or threshold are reached.
        Example:
        AggregatorRule(rm, '/incoming/A(.............).L1A_LAC.bz2', "l3", '/l3/modisa-%Y%j.nc', ['%Y%j'], 288, 43200, '\\1', '%Y%j%H%M%S', 86400)
        """
        def __init__(self, rm, precondition, step, postcondition, parameters, expected_size, time_threshold, time_element=None, time_format=None, period=None, collating=True):
            self.rm = rm
            self.pattern = re.compile(precondition)
            self.step = step
            self.postcondition = postcondition
            self.parameters = parameters
            self.expected_size = expected_size
            self.time_threshold = time_threshold
            self.time_element = time_element
            self.time_format = time_format
            self.period = period
            self.collating = collating
            self.tasks = []
        def __str__(self):
            return 'ru ' + self.step + ' ' + self.pattern.pattern + ' ' + str(self.expected_size) + ' ' + str(self.period) + ' ' + str(len(self.tasks))
        def _start_time(self, event_time):
            if self.period:
                beginning_of_year = datetime(event_time.year, 1, 1)
                since_january_first = event_time - beginning_of_year
                return beginning_of_year + timedelta(seconds=int(since_january_first.total_seconds() / self.period) * self.period)
            else:
                return event_time
        def _execution_time(self, task_time):
            if self.period:
                nominal_execution_time = task_time + timedelta(seconds=self.period + self.time_threshold)
                dynamic_execution_time = datetime.utcnow() + timedelta(seconds=(self.time_threshold + 1) / 2)
                if nominal_execution_time > dynamic_execution_time:
                    return nominal_execution_time
                else:
                    return dynamic_execution_time
            else:
                return datetime.utcnow() + timedelta(seconds=self.time_threshold)
        def _search_task(self, task_time):
            for task in self.tasks:
                if task.interval_start == task_time:
                    return task
            return None
        def apply(self, event):
            match = self.pattern.match(event)
            if match is not None:
                if self.time_element and self.time_format:
                    # periodic aggregation and aggregation with time as sorting criterion
                    event_time = datetime.strptime(match.expand(self.time_element), self.time_format)
                    task_time = self._start_time(event_time)
                    task = self._search_task(task_time)
                    if task is None:
                        execution_time = self._execution_time(task_time)
                        task = RMonitor.AggregatorTask(self, task_time, execution_time)
                        self.tasks.append(task)
                        self.rm.register_timer_task(task)
                    elif self.period:
                        # wait at least half the time threshold after an event for periodic aggregation
                        execution_time = datetime.utcnow() + timedelta(seconds=(self.time_threshold + 1) / 2)
                        if execution_time > task.nexttime:
                            self.rm.timer.cancel(task)
                            task.nexttime = execution_time
                            self.rm.timer.schedule(task)
                else:
                    # non-periodic count-based and time threshold-based aggregation
                    if self.tasks:
                        task = self.tasks[0]
                    else:
                        task_time = datetime.utcnow()
                        execution_time = task_time + timedelta(seconds=self.time_threshold)
                        task = RMonitor.AggregatorTask(self, task_time, execution_time)
                        self.tasks.append(task)
                        self.rm.register_timer_task(task)
                # event bookkeeping
                self.rm.add_current_event(event)
                task.add_event(event, match)
                # check whether expected count is reached, maybe apply rule
                if len(task.conditions) >= self.expected_size:
                    parameters = [task.interval_start.strftime(p) for p in self.parameters]
                    self.tasks.remove(task)
                    self.rm.timer.cancel(task)
                    task.interval_start = None  # used as marker for synchronisation with task run method
                    super(RMonitor, self.rm).execute(self.step, task.conditions, task.postconditions, parameters)
                    #for p in task.postconditions:
                    #    self.rm.trigger(p)

    class FileTailTrigger(Thread):
        """
        """
        def __init__(self, rm, path, period=10, begin=None, pattern=None, filter=None, insertion_start=None):
            Thread.__init__(self, name=path)
            self.rm = rm
            self.path = path
            self.file = None
            self.cursor = 0
            self.period = period
            self.begin = begin
            self.pattern = re.compile(pattern) if pattern else None
            self._filter = filter
            self._condition = Condition()
            self._active = True
            self.count = 0
            self._insertion_start = insertion_start
        def __str__(self):
            return "tr " + self.path + ' ' + str(self.count)
        def run(self):
            inode = None
            while self._active:
                stat = os.stat(self.path)
                if stat[1] != inode:
                    inode = stat[1]
                    if self.file is not None:
                        self.file.close()
                    self.file = open(self.path, 'r')
                    self.cursor = 0
                    self.count = 0
                while self.cursor < stat[6]:
                    line = self.file.readline()
                    pos = line.find('\t')
                    if pos == -1:
                        event = line[:-1]
                    else:
                        event = line[:pos]
                    self.cursor += len(line)
                    if event < self.begin or (self.pattern and not self.pattern.match(event)) or (self._filter and self._filter(event)):
                        continue
                    if self._insertion_start:
                        insertion_date = line[line.rfind('\t')+1:]
                        if insertion_date < self._insertion_start:
                            continue
                    self.count += 1
                    self.rm.trigger(event)
                with self._condition:
                    if self._active:
                        self._condition.wait(self.period)
        def stop(self):
            with self._condition:
                self._active = False
                self._condition.notify()

    class RemoteFileTailTrigger(FileTailTrigger):
        """
        """
        def __init__(self, rm, host, user, path, period=10, begin=None, pattern=None, filter=None, insertion_start=None):
            RMonitor.FileTailTrigger.__init__(self, rm, path, period, begin, pattern, filter, insertion_start)
            self.host = host
            self.user = user
        def __str__(self):
            return "tr " + self.host + ':' + self.path + ' ' + str(self.count)
        def run(self):
            ftp = None
            list_file = None
            ssh = SSHClient()
            ssh.load_system_host_keys(os.environ['HOME']+'/.ssh/known_hosts')
            ssh.set_missing_host_key_policy(AutoAddPolicy())
            #
            while self._active:
                try:
                    if ftp is None:
                        ssh.connect(self.host, username=self.user)
                        ftp = ssh.open_sftp()
                        list_file = ftp.open(self.path, 'r+')
                        self.cursor = 0
                        self.count = 0
                    stat = ftp.stat(self.path)
                    while self.cursor < stat.st_size:
                        line = list_file.readline()
                        if not line:
                            raise Exception('list file replaced on remote server')
                        pos = line.find('\t')
                        if pos == -1:
                            event = line[:-1]
                        else:
                            event = line[:pos]
                        self.cursor += len(line)
                        if event < self.begin or (self.pattern and not self.pattern.match(event)) or (self._filter and not self._filter(event)):
                            continue
                        if self._insertion_start:
                            insertion_date = line[line.rfind('\t')+1:]
                            if insertion_date < self._insertion_start:
                                continue
                        self.count += 1
                        self.rm.trigger(event)
                except Exception as e:
                    print(e)
                    if list_file is not None:
                        list_file.close()
                        list_file = None
                    if ftp is not None:
                        ftp.close()
                    ssh.close()
                    ftp = None
                with self._condition:
                    if self._active:
                        self._condition.wait(self.period)


    class TriggerTask(Task):
        """
        Worker task that applies all rules to new event and maintains current events and passed events
        """
        def __init__(self, rm, event, open_count=0):
            self.rm = rm
            self.event = event
            self.open_count = open_count
        def run(self):
            #print '... mutex2 2 acquiring'
            with self.rm._mutex2:
                #print '... mutex2 2 acquired'
                if self.event in self.rm.passed_events or self.event in self.rm.current_events:
                    return
                self.rm.current_events[self.event] = self.open_count
                #print '... mutex 7 acquiring'
                with self.rm._mutex:
                    #print '... mutex 7 acquired'
                    self.rm._mark_inputs([self.event])
                    self.rm._check_for_mature_tasks()
                #print '... mutex 7 released'
                for rule in self.rm.rules:
                    rule.apply(self.event)
                # event is passed if no rule is applicable
                if self.rm.current_events[self.event] == 0:
                    self.rm.current_events.pop(self.event)
                    self.rm.passed_events.add(self.event)
                    self.rm.passed_file.write(self.event + '\n')
                    self.rm.passed_file.flush()
                #print '... mutex 7 acquiring'
                with self.rm._mutex:
                    #print '... mutex 7 acquired'
                    self.rm._write_status()
                #print '... mutex 7 released'
            #print '... mutex2 2 released'

    _memo = {}
        
    def __init__(self, request='', hosts=[('localhost',4)], types=[], weights=[], swd=None, cache=None, logdir='.', simulation=False, delay=None, fair=True, script=None, polling=None, inputs=[], period=5, retrycode=None):
        """
        Initiates monitor, reads report, creates thread pool.
        mutex2 protects access to passed events and current events
        """
        PMonitor.__init__(self, inputs, request=request, hosts=hosts, types=types, weights=weights, swd=swd, cache=cache, logdir=logdir, simulation=simulation, delay=delay, fair=fair, script=script, polling=polling, period=period, retrycode=retrycode)
        #self._mutex2 = Lock()
        self._mutex2 = self._mutex
        #print '... mutex2 3 acquiring'
        with self._mutex2:
            #print '... mutex2 3 acquired'
            self.worker = RMonitor.Worker('rm-worker')
            self.rules = []
            self.triggers = []
            self.timer = None
            self.passed_file = None
            self.passed_events = set([])
            self.current_events = {}
            self._reported_outputs_handled = False
            self._maybe_read_passed_events(request + '.passed')
        #print '... mutex2 3 released'

    def _maybe_trigger_for_reported_outputs(self):
        with self._mutex2:
            if not self._reported_outputs_handled:
                for line in self._commands:
                    if not line.startswith('#output'):
                        output = line[line.rfind(' ')+1:]
                        if not output in self.passed_events:
                            self.trigger(output)
            self._reported_outputs_handled = True

    def _maybe_read_passed_events(self, passed_path):
        """
        Reads report containing lines with events, e.g.
          /calvalus/projects/glass/incoming/LANDSAT-DATA/Ijsselmeer/LC81910832014288X00.zip
        """
        if glob(passed_path):
            self.passed_file = open(passed_path, 'r+')
            for line in self.passed_file.readlines():
                self.passed_events.add(line[:-1])
        else:
            self.passed_file = open(passed_path, 'w')

    def register_rule(self, rule):
        """
        Adds pattern matching rule to the rule set
        """
        with self._mutex2:
            self.rules.append(rule)
            with self._mutex:
                self._write_status()

    def register_trigger(self, trigger):
        """
        starts a trigger thread
        """
        with self._mutex2:
            self.triggers.append(trigger)
            self._maybe_trigger_for_reported_outputs()
            trigger.start()
            with self._mutex:
                self._write_status()

    def register_timer_task(self, task):
        if not self.timer:
            self.timer = RMonitor.Timer('rm-timer')
        self.timer.schedule(task)
        with self._mutex:
            self._write_status()

    def trigger(self, event, open_count=0):
        with self._mutex2:
            if not event in self.passed_events:
                self.worker.add(RMonitor.TriggerTask(self, event, open_count=open_count))

    def memorize(self, name, event):
        self._memo[name] = event
        return event
        
    def recall(self, name):
        return self._memo.pop(name)

    def close_trigger(self, event):
        #print '... mutex2 2 acquiring'
        with self._mutex2:
            #print '... mutex2 2 acquired'
            x = self.current_events.get(event)
            if x and x > 1:
                self.current_events[event] = x - 1
            elif x:
                self.current_events.pop(event)
                self.passed_events.add(event)
                self.passed_file.write(event + '\n')
                self.passed_file.flush()
            #print '... mutex 7 acquiring'
            with self._mutex:
                #print '... mutex 7 acquired'
                self._write_status()
            #print '... mutex 7 released'
        #print '... mutex2 2 released'

    def close(self):
        if self.timer:
            self.timer.stop()
        self.worker.stop()
        for trigger in self.triggers:
            trigger.stop()

    def _no_of_timer_tasks(self) :
        if self.timer:
            return len(self.timer.tasks)
        else:
            return 0

    def add_current_event(self, event):
        self.current_events[event] = self.current_events.get(event, 0) + 1

    def add_current_events(self, events):
        for event in events:
            self.current_events[event] = self.current_events.get(event, 0) + 1

    def execute(self, call, inputs, outputs, parameters=[], priority=1, collating=True, async_=None, logprefix=None):
        self.add_current_events(inputs)
        super(RMonitor, self).execute(call, inputs, outputs, parameters, priority, collating, async_, logprefix)
            
    def _observe_step(self, call, inputs, outputs, parameters, code):
        if code == 0:
            #print '... mutex2 4 acquiring'
            with self._mutex2:
                #print '... mutex2 4 acquired'
                flush_required = False
                for input in inputs:
                    x = self.current_events.get(input)
                    if x and x > 1:
                        self.current_events[input] = x - 1
                    elif x:
                        self.current_events.pop(input)
                        self.passed_events.add(input)
                        self.passed_file.write(input + '\n')
                        flush_required = True
                if flush_required:
                    self.passed_file.flush()
                for output in outputs:
                    self.trigger(output)
            #print '... mutex2 4 released'

    def _write_status(self, with_backlog=False):
        self._status.seek(0)
        self._status.write('{0} triggers, {1} rules, {2} timer tasks, {3} current events, {4} passed events\n'.
        format(len(self.triggers), len(self.rules), self._no_of_timer_tasks(), len(self.current_events), len(self.passed_events)))
        for l in self.triggers:
            self._status.write('{0}\n'.format(l))
        for l in self.rules:
            self._status.write('{0}\n'.format(l))
        if self.timer:
            for l in self.timer.tasks:
                self._status.write('{0}\n'.format(l))
        #for e in self.current_events:
        #    self._status.write('ev {0} {1}\n'.format(e, self.current_events[e]))
        self._status.write('{0} created, {1} running, {2} backlog, {3} processed, {4} failed\n'.
        format(self._created, len(self._running), len(self._backlog), self._processed, len(self._failed)))
        for l in self._failed:
            self._status.write('f {0}\n'.format(l))
        for l in self._running:
            if isinstance(self._running[l], PMonitor.Args):
                self._status.write('r [{0}] {1}\n'.format(self._running[l].external_id, l))
            elif isinstance(self._running[l], str):
                self._status.write('r [{0}] {1}\n'.format(self._running[l], l))
            else:
                self._status.write('r {0}\n'.format(l))
        if with_backlog:
            for r in self._backlog:
                self._status.write('b {0} {1} {2} {3}\n'.format(PMonitor.Args.get_call(r.args),
                                                                ' '.join(PMonitor.Args.get_parameters(r.args)),
                                                                ' '.join(PMonitor.Args.get_inputs(r.args)),
                                                                ' '.join(PMonitor.Args.get_outputs(r.args))))
        self._status.truncate()
        self._status.flush()
        os.fsync(self._status)

