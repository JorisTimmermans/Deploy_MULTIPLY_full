# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from VITO ProbaV server"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.1"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# python3 compatibility using six

import lxml
import lxml.html
import datetime
import pytz
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile

class HttpMonitor(IMonitor):
    _timeout=600
    _cookie=None

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None, destroot=".", destmapping=None, destflatten=False, timemapping=None, destreplace=False):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor, destroot, False, destmapping, destflatten, timemapping, destreplace)
        if srcpassword is not None:
            # authentication
            manager = urllib.request.HTTPPasswordMgrWithDefaultRealm()
            manager.add_password(None, 'https://'+srchost+srcroot, srcuser, srcpassword)
            dataAuthHandler = urllib.request.HTTPBasicAuthHandler(manager)
            urllib.request.install_opener(urllib.request.build_opener(dataAuthHandler))

    def ls(self, ifile):
        l = []
        opath = self._output_of(ifile.path)
        is_on_cursor_path = self._srccursor is not None and self._srccursor.startswith(opath)
        print('QUERY=' + 'http://' + self._srchost + self._srcroot + ifile.path)
        response = self._urlopen('http://' + self._srchost + self._srcroot + ifile.path, timeout=self._timeout)
        html = response.read()
        #print 'RESPONSE=' + html + '\nEND RESPONSE'
        xhtml = lxml.html.fromstring(html)
        for i in xhtml[1].xpath('//table/tr[td/a]'):
            if len(i) == 4:
                name = i[0].text
                if name is None:
                    continue
                name = name.strip()
                pathname = ifile.path + name
                opath = self._output_of(pathname)
                print('opath=' + opath)
#                if not self._srccursor or self._srccursor.startswith(opath) or opath >= self._srccursor[:len(opath)]:
                if is_on_cursor_path and self._srccursor.startswith(opath):
                    print('clearing opaths (4) before cursor ' + self._srccursor)
                    while len(l) > 0:
                        l.pop()
                    if opath == self._srccursor and self._srccompletion == 'c':
                        continue
                s = i[1].text.strip();
                if s[-2:] == 'GB':
                    s = int(s[:-3]) * 1024 * 1024 * 1024
                elif s[-2:] == 'MB':
                    s = int(s[:-3]) * 1024 * 1024
                elif s[-2:] == 'kB':
                    s = int(s[:-3]) * 1024
                elif s[-5:] == 'bytes':
                    s = int(s[:-6])
                else:
                    s = int(s)
                if not self._pattern or self._pattern.match(name):
                    print('href=' + 'http://' + self._srchost + self._srcroot + ifile.path + i[3][0].get('href'))
                    l.append(IFile(opath, 'http://' + self._srchost + self._srcroot + ifile.path + i[3][0].get('href'), s))
            elif len(i) == 1:
                name = i[0][0].text
                if name is None:
                    continue
                name = name.strip()
                #print name
                pathname = ifile.path + name
                if i[0][0].get('href')[-1:] == '/':
                    opath = self._output_of(pathname + '/')
                else:
                    opath = self._output_of(pathname)
                print('opath=' + opath)
                if is_on_cursor_path and self._srccursor.startswith(opath):
                    print('clearing opaths (1) before cursor ' + self._srccursor)
                    while len(l) > 0:
                        l.pop()
                    if opath == self._srccursor and self._srccompletion == 'c':
                        continue
                if i[0][0].get('href')[-1:] == '/':
                    l.append(IFile(ifile.path + i[0][0].get('href').split('/')[-2] + '/'))
                elif not self._pattern or self._pattern.match(name):
                    l.append(IFile(opath, i[0][0].get('href'), int(i[0][0].text)))
        # l.sort()
        return l

    def transfer(self, ifile):
        if ifile in self._history:
            print('skipping', ifile.path)
            return
        self.prepare_transfer(ifile)
        response = self._urlopen(ifile.url, timeout=self._timeout)
        if ifile.size == 0:
            if not 'content-length' in response.headers:
                print('response does not contain binary as expected:')
                print(response.read())
                raise IOError
            ifile.size = int(response.headers['Content-Length'])
        pos = 0
        statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                while (True):
                    block = response.read(8192)
                    if len(block) == 0:
                        break
                    file.write(block)
                    pos += len(block)
                    if pos == statuspos:
                        now = datetime.datetime.now(pytz.timezone('UTC'))
                        delta = now - ifile.time
                        seconds = delta.days * 86400 + delta.seconds
                        if seconds > 0:
                            ifile.datarate = int(pos * 8 / 1024 / seconds)
                            self._write_status([ifile], [], [])
        except Exception as e:
            self._write_status([], [], [ifile])
            raise e
        self.finish_transfer(ifile)

    def _urlopen(self, url, timeout=None):
        if self._cookie != None:
            url = urllib.request.Request(url)
            url.add_header('cookie', self._cookie)
        print(url)
        response = urllib.request.urlopen(url, timeout=timeout)
        if self._cookie == None:
            self._cookie = response.headers.get('Set-Cookie')
            print(('cookie=' + self._cookie))
        return response
