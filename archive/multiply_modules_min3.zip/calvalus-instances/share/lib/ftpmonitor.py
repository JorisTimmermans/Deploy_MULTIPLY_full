# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from FTP servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.1"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# python3 compatibility using six

import ftplib
import datetime
from imonitor import IMonitor
from imonitor import IFile

class FtpMonitor(IMonitor):

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None, destroot=".", srcremove=False, destmapping=None, destflatten=False):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor, destroot, srcremove, destmapping, destflatten)
        self._ftp = ftplib.FTP()

    def ls(self, ifile):
        print('looking for data in ' + ifile.path)
        opath = self._output_of(ifile.path)
        is_beyond_cursor = self._srccursor is None or not self._srccursor.startswith(opath)
        try:
            l = []
            self._ftp.dir(self._srcroot + ifile.path, lambda x: self._maybe_insert(l, ifile.path, is_beyond_cursor, x))
            return l
        except Exception as e:
            self._ftp.connect(self._srchost)
            self._ftp.login(self._srcuser, self._srcpassword)
            l = []
            self._ftp.dir(self._srcroot + ifile.path, lambda x: self._maybe_insert(l, ifile.path, is_beyond_cursor, x))
            return l

    def _maybe_insert(self, list, path, is_beyond_cursor, line):
        l = line.split()
        name = ' '.join(l[8:])
        size = l[4]
        # check whether path is young to avoid retrieval of file being currently written
        now = datetime.datetime.today()
        try:
            # Aug 15 17:45
            date = datetime.datetime.strptime(l[5] + ' ' + l[6] + ' ' + l[7] + ' ' + str(now.year), "%b %d %H:%M %Y")
            if date > now + datetime.timedelta(1):
                date = datetime.datetime.strptime(l[5] + ' ' + l[6] + ' ' + l[7] + ' ' + str(now.year-1), "%b %d %H:%M %Y")
        except Exception as e:
            try:
                # Jul 10  2013
                date = datetime.datetime.strptime(l[5] + ' ' + l[6] + ' ' + l[7], "%b %d  %Y")
            except Exception as e:
                print('cannot parse date in line ' + line)
                date = now
        age = now - date
        threshold = datetime.timedelta(seconds=1800)
        isYoung = age < threshold
        #
        filetype = line[0]  # first letter only
        pathname = path + name
        if filetype == 'd':
            opath = self._output_of(pathname + '/')
        else:
            opath = self._output_of(pathname)
#        if self._srccursor \
#           and self._srccursor.startswith(opath[:opath.rfind('/')]) \
#           and (opath < self._srccursor[:len(opath)]
#                or (opath == self._srccursor and self._srccompletion == 'c')):
#            print 'skipping pre-cursor entry', pathname
#            return
        if not is_beyond_cursor and self._srccursor.startswith(opath):
            # remove all collected entries before cursor
            while len(list) > 0:
                print('skipping pre-cursor entry ' + list.pop().url)
            if opath == self._srccursor and self._srccompletion == 'c':
                print('skipping pre-cursor entry ' + pathname)
                return
        if filetype != 'd' and self._pattern and not self._pattern.match(name):
            return
        if filetype == 'd':
            ifile = IFile(pathname + '/')
        else:
            ifile = IFile(opath, pathname, int(size))
        if ifile in self._history:
            print('skipping history entry ' + ifile.path)
            return
        if filetype != 'd' and isYoung:
            print('skipping young entry {}: {}'.format(ifile.path, str(date))
            return
        for i in range(len(list)):
            if ifile.path <= list[i].path:
                list.insert(i, ifile)
                return
        list.append(ifile)

    def transfer(self, ifile):
        self.prepare_transfer(ifile)
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                self._ftp.retrbinary("RETR " + self._srcroot + ifile.url, file.write)
        except:
            try:
                self._ftp.connect(self._srchost)
                self._ftp.login(self._srcuser, self._srcpassword)
                with open(self._destroot + ifile.path, "wb") as file:
                    self._ftp.retrbinary("RETR " + self._srcroot + ifile.url, file.write)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
        self.finish_transfer(ifile)
        if self._srcremove:
            try:
                with open('/dev/null', "rb") as file:
                    self._ftp.storbinary("STOR " + self._srcroot + ifile.url + '.ingested', file)
#                self._ftp.rename(self._srcroot + ifile.path, self._srcroot + ifile.url + '.tobedeleted')
                self._ftp.delete(self._srcroot + ifile.url)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
