# -*- coding: utf-8 -*-

"""Ingestion function for systematic queries to opensearch catalogue servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.1"
__email__ = "info@brockmann-consult.de"
__status__ = "Development"

# changes in 1.1
# python3 compatibility using six

import time
import subprocess
import traceback
import datetime
import pytz
import sys
import shutil
from lxml import etree
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile

class OpenSearchMonitor(IMonitor):
#    _timeout=600
    _timeout=None
    _chunksize=10
    _largeresultthreshold=100
    _cookie = None
    _areas = None
    _namespaces = { 'a' : 'http://www.w3.org/2005/Atom',
                    'o' : 'http://a9.com/-/spec/opensearch/1.1/',
                    'm' : 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
                    'd' : 'http://schemas.microsoft.com/ado/2007/08/dataservices'}

    def __init__(self, request, srcbaseurl, areas, srccursor=None, srcpattern=None, timemapping=None):
        IMonitor.__init__(self, request, None, None, None, srcbaseurl, None, srccursor, timemapping=timemapping)
        self._areas = areas
        self._search_base_url = srcbaseurl
        self._srcpattern = srcpattern

    def ls(self, ifile):
        accu = []
        now = self._format_date(datetime.datetime.utcnow())
        # distinguish initial query ...
        if ifile.path == '/':
            begin = self._srccursor[:-1]
            for i in range(-1, -len(self._history)-1, -1):
                try:
                    begin = self._ingestion_date_of(self._history[i].path[self._history[i].path.rfind('/')+1:])
                    break
                except (urllib.error.HTTPError) as e:
                    print('{} retrieval of ingestion date failed: {}'.format(self._history[i].path[self._history[i].path.rfind('/')+1:], str(e)))
                    raise e
                except (Exception) as e:
                    traceback.print_exc(file=sys.stdout)
                    print('{} no longer available, using previous product as cursor'.format(self._history[i].path[self._history[i].path.rfind('/')+1:]))
        # ... and subsequent query, ifile.path=prevDate/ e.g. 2015-09-08T00:00:00.000Z/
        else:
            begin = ifile.path[:-1]
        # determine end of interval by adding repeat cycle
        end = self._format_date(self._date_of(begin) + datetime.timedelta(10))
        # loop in case end must be reduced to avoid result_too_large
        while True:
            result_too_large = False
            # do queries for all areas before sorting all by ingestion date
            for area in list(self._areas.keys()):
                row = 0
                size = 1
                # do query in chunks
                while row < size:
                    size = self._search(begin, end, area, row, self._chunksize, accu)
                    row += self._chunksize
                    # redo with reduced end if a query returns too large result
                    if size > self._largeresultthreshold:
                        result_too_large = True
                        end=self._format_date(self._date_of(begin) + (self._date_of(end) - self._date_of(begin)) / 2)
                        accu=[]
                        break
                # restart for all areas with same end in case result for one is too large
                if result_too_large:
                    break
            if not result_too_large:
                break
        accu.sort()
        accu = [d_i[1] for d_i in accu]
        # initiate next query from end onwards after files of this interval are ingested
        if end < now:
            accu.append(IFile(end + '/'))
        print('ls returns ' + str(len(accu)) + ' entries')
        for i in accu:
            print(i.path)
        return accu

    def _search(self, begin, end, area, row, chunksize, accu):
        query = ( self._search_base_url + 
                  '&parentIdentifier=' + self._srcpattern +
#                  '&startDate=' + begin +
#                  '&endDate=' + end +
                  '&creationDate:[' + begin + ' TO ' + end + ']' +
#                  '&geometry:"Intersects(' + self._areas[area] +  ')' +
                  '&geometry=' + self._areas[area] +
                  '&startRecord=' + str(row+1) + 
                  '&maximumRecords=' + str(chunksize) )
        query = query.replace(' ', '%20')
        print(query)
        # response = self._urlopen(query, context=self.ctx)
        response = self._urlopen(query)
        xml = response.read()
        print(xml)
        dom = etree.fromstring(xml)
        hits = int(dom.xpath('/a:feed/o:totalResults', namespaces=self._namespaces)[0].text)
        print('hits=' + str(hits))
        for i in dom.xpath('/a:feed/a:entry',namespaces=self._namespaces):
#            name = i.xpath('a:str[@name="identifier"]',namespaces=self._namespaces)[0].text
            name = i.xpath('dc:identifier',namespaces=self._namespaces)[0].text
#            url = i.xpath('a:id',namespaces=self._namespaces)[0].text
            url = i.xpath('a:link[@title="Download"]/@href',namespaces=self._namespaces)[0].text
#            length = i.xpath('a:str[@name="size"]',namespaces=self._namespaces)[0].text
            length = "0"
#            ingestiondate = i.xpath('a:date[@name="ingestiondate"]',namespaces=self._namespaces)[0].text
            ingestiondate = i.xpath('a:date[@name="ingestiondate"]',namespaces=self._namespaces)[0].text
            print((area, name, url, length, ingestiondate))
            opath = '/' + area + self._output_of(name)
            accu.append((ingestiondate, IFile(opath, url, self._size_of(length))))
        return hits

    def _ingestion_date_of(self, name):
        url = self._search_base_url + '$select=IngestionDate&$filter=substringof(\'' + name + '\',Name)'
        print(url)
        response = self._urlopen(url, timeout=self._timeout)
        xml = response.read()
        print(xml)
        dom = etree.fromstring(xml)
        return dom.xpath('/a:feed/a:entry/m:properties/d:IngestionDate', namespaces=self._namespaces)[0].text + 'Z'

    # md5sum : https://scihub.esa.int/dhus/odata/v1/Products('33a8c81f-fe4f-4530-ab49-6bd15d2e7403')/Checksum
    # <?xml version='1.0' encoding='utf-8'?><Checksum xmlns="http://schemas.microsoft.com/ado/2007/08/dataservices" xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" m:type="DHuS.Checksum"><Algorithm>MD5</Algorithm><Value>981F9808B85AEFA182F1678529B9F58F</Value></Checksum>
    def _checksum_of(self, uuid):
        url = 'https://' + self._srchost + self._srcroot + "('" + uuid + "')/Checksum"
        print(url)
        response = self._urlopen(url, timeout=self._timeout)
        xml = response.read()
        print(xml)
        dom = etree.fromstring(xml)
        return dom.xpath('/d:Checksum/d:Value', namespaces=self._namespaces)[0].text.lower()

    def _urlopen(self, url, timeout=None):
        if self._cookie != None:
            url = urllib.request.Request(url)
            #p1 = self._cookie.find("JSESSIONID=")
            #p2 = self._cookie.find(";", p1)
            #sessionId = self._cookie[p1+11:p2]
            #p1 = self._cookie.find("dhusAuth=")
            #p2 = self._cookie.find(";", p1)
            #dhusAuth = self._cookie[p1+9:p2]
            #print(dhusAuth)
            #print(sessionId)
            url.add_header('cookie', self._cookie)
            #url.add_header('JSESSIONID', sessionId)
            #url.add_header('dhusAuth', dhusAuth)
        response = urllib.request.urlopen(url, timeout=timeout)
        if self._cookie == None:
            self._cookie = response.headers.get('Set-Cookie')
            print('cookie=' + str(self._cookie))
        return response

    def _filename_of(self, path):
        return path[path.rfind('/')+1:]

    def _date_of(self, str):
        return datetime.datetime.strptime(str, '%Y-%m-%dT%H:%M:%S.%fZ')

    def _format_date(self, date):
        return date.strftime('%Y-%m-%dT%H:%M:%S.%fZ')[:-4]+'Z'

    def _size_of(self, value_and_unit):
        value,unit = value_and_unit.split()
        if value.startswith('NaN'):
            return 1024 * 1024 * 1024
        if unit == 'GB':
            return int(float(value) * 1024 * 1024 * 1024)
        if unit == 'MB':
            return int(float(value) * 1024 * 1024)
        if unit == 'KB':
            return int(float(value) * 1024)
        else:
            raise Exception('cannot parse value and unit in ' + value_and_unit)

    def transfer(self, ifile):
        raise Error('not implememented')

    def verify(self, p, expected_md5sum=None):
        raise Error('not implememented')

