import ftplib
import datetime
from imonitor import IMonitor
from imonitor import IFile

__author__ = 'boe'

class FtpListMonitor(IMonitor):

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, file_list, destroot=".", destmapping=None, destflatten=False):
        self._file_list = file_list
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, None, None, destroot, False, destmapping, destflatten)
        self._ftp = ftplib.FTP()

    def ls(self, ifile):
        iFiles = [IFile(self._output_of(pathname), pathname, 1) for pathname in self._file_list]
        return [iFile for iFile in iFiles if not iFile in self._history]

    def transfer(self, ifile):
        self.prepare_transfer(ifile)
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                self._ftp.retrbinary("RETR " + self._srcroot + ifile.url, file.write)
        except:
            try:
                self._ftp.connect(self._srchost)
                self._ftp.login(self._srcuser, self._srcpassword)
                with open(self._destroot + ifile.path, "wb") as file:
                    self._ftp.retrbinary("RETR " + self._srcroot + ifile.url, file.write)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
        self.finish_transfer(ifile)
