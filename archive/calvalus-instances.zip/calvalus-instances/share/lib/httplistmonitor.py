import datetime
import pytz
import lxml
import lxml.html
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile

__author__ = 'boe'

class HttpListMonitor(IMonitor):

    # destroot param is expected to feature a trailing slash
    def __init__(self, request, srchost, srcroot, file_list, srcuser=None, srcpassword=None, destroot="./"):
        self._file_list = file_list
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, None, None, destroot)

    def ls(self, ifile):
        iFiles = [IFile(filename, 'http://' + self._srchost + '/' + self._srcroot + '/' + filename) for filename in self._file_list]
        return [iFile for iFile in iFiles if not iFile in self._history]

    def transfer(self, ifile):
        self.prepare_transfer(ifile)
        response = urllib.request.urlopen(ifile.url)
        ifile.size = int(response.info().getheader('Content-Length'))        
        pos = 0
        statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                while (True):
                    block = response.read(8192)
                    if len(block) == 0:
                        break
                    file.write(block)
                    pos += len(block)
                    if pos == statuspos:
                        now = datetime.datetime.now(pytz.timezone('UTC'))
                        delta = now - ifile.time
                        seconds = delta.days * 86400 + delta.seconds
                        if seconds > 0:
                            ifile.datarate = int(pos * 8 / 1024 / seconds)
                            self._write_status([ifile], [], [])
        except Exception as e:
            self._write_status([], [], [ifile])
            raise e
        self.finish_transfer(ifile)
